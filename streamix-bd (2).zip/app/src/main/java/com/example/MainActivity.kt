package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ContentItem
import com.example.data.model.Episode
import com.example.data.repository.SeedData
import com.example.data.repository.StreamixRepository
import com.example.ui.components.StreamixTopHeader
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.admin.AdminLoginScreen
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.SignUpScreen
import com.example.ui.screens.categories.CategoriesScreen
import com.example.ui.screens.detail.ContentDetailScreen
import com.example.ui.screens.downloads.DownloadsScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.mylist.MyListScreen
import com.example.ui.screens.player.VideoPlayerScreen
import com.example.ui.screens.premium.PremiumSubscriptionScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.request.ContentRequestScreen
import com.example.ui.screens.search.SearchScreen
import com.example.ui.theme.*
import kotlinx.coroutines.delay

enum class ScreenRoute {
    SPLASH,
    LOGIN,
    SIGN_UP,
    FORGOT_PASSWORD,
    MAIN_APP,
    SEARCH,
    CONTENT_DETAIL,
    VIDEO_PLAYER,
    CONTENT_REQUEST,
    PREMIUM,
    ADMIN_LOGIN,
    ADMIN_DASHBOARD
}

enum class BottomTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME("Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home_tab"),
    CATEGORIES("Explore", Icons.Filled.Category, Icons.Outlined.Category, "nav_categories_tab"),
    MY_LIST("My List", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "nav_mylist_tab"),
    DOWNLOADS("Downloads", Icons.Filled.Download, Icons.Outlined.Download, "nav_downloads_tab"),
    PROFILE("Account", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile_tab")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                StreamixAppRoot()
            }
        }
    }
}

@Composable
fun StreamixAppRoot() {
    val context = LocalContext.current
    val repository = remember { StreamixRepository(context) }
    val currentUser by repository.currentUser.collectAsStateWithLifecycle()

    var currentRoute by remember { mutableStateOf(ScreenRoute.SPLASH) }
    var selectedBottomTab by remember { mutableStateOf(BottomTab.HOME) }

    // Navigation argument states
    var selectedContentId by remember { mutableStateOf<String?>(null) }
    var selectedPlayerContent by remember { mutableStateOf<ContentItem?>(null) }
    var selectedPlayerEpisode by remember { mutableStateOf<Episode?>(null) }
    var initialCategorySlug by remember { mutableStateOf("all") }

    // Initial Splash / Auth resolution
    LaunchedEffect(Unit) {
        delay(1200)
        if (currentUser != null) {
            currentRoute = ScreenRoute.MAIN_APP
        } else {
            currentRoute = ScreenRoute.LOGIN
        }
    }

    // Hardware / System Back Button Handling
    BackHandler(enabled = currentRoute != ScreenRoute.MAIN_APP || selectedBottomTab != BottomTab.HOME) {
        when (currentRoute) {
            ScreenRoute.SEARCH -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.CONTENT_DETAIL -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.VIDEO_PLAYER -> {
                if (selectedContentId != null) {
                    currentRoute = ScreenRoute.CONTENT_DETAIL
                } else {
                    currentRoute = ScreenRoute.MAIN_APP
                }
            }
            ScreenRoute.CONTENT_REQUEST -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.PREMIUM -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.ADMIN_LOGIN -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.ADMIN_DASHBOARD -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.SIGN_UP, ScreenRoute.FORGOT_PASSWORD -> currentRoute = ScreenRoute.LOGIN
            ScreenRoute.LOGIN -> currentRoute = ScreenRoute.MAIN_APP
            ScreenRoute.MAIN_APP -> {
                if (selectedBottomTab != BottomTab.HOME) {
                    selectedBottomTab = BottomTab.HOME
                }
            }
            else -> {}
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MidnightBlack
    ) {
        when (currentRoute) {
            ScreenRoute.SPLASH -> {
                SplashScreen()
            }

            ScreenRoute.LOGIN -> {
                LoginScreen(
                    repository = repository,
                    onLoginSuccess = {
                        currentRoute = ScreenRoute.MAIN_APP
                    },
                    onNavigateToSignUp = {
                        currentRoute = ScreenRoute.SIGN_UP
                    },
                    onNavigateToForgotPassword = {
                        currentRoute = ScreenRoute.FORGOT_PASSWORD
                    },
                    onNavigateToAdmin = {
                        currentRoute = ScreenRoute.ADMIN_LOGIN
                    }
                )
            }

            ScreenRoute.SIGN_UP -> {
                SignUpScreen(
                    repository = repository,
                    onSignUpSuccess = {
                        currentRoute = ScreenRoute.MAIN_APP
                    },
                    onNavigateToLogin = {
                        currentRoute = ScreenRoute.LOGIN
                    }
                )
            }

            ScreenRoute.FORGOT_PASSWORD -> {
                ForgotPasswordScreen(
                    repository = repository,
                    onPasswordResetSuccess = {
                        currentRoute = ScreenRoute.LOGIN
                    },
                    onNavigateToLogin = {
                        currentRoute = ScreenRoute.LOGIN
                    }
                )
            }

            ScreenRoute.SEARCH -> {
                SearchScreen(
                    repository = repository,
                    onContentClick = { item ->
                        selectedContentId = item.id
                        currentRoute = ScreenRoute.CONTENT_DETAIL
                    },
                    onBackClick = {
                        currentRoute = ScreenRoute.MAIN_APP
                    }
                )
            }

            ScreenRoute.ADMIN_LOGIN -> {
                AdminLoginScreen(
                    repository = repository,
                    onAdminLoginSuccess = {
                        currentRoute = ScreenRoute.ADMIN_DASHBOARD
                    },
                    onBackToUserApp = {
                        currentRoute = ScreenRoute.MAIN_APP
                    }
                )
            }

            ScreenRoute.ADMIN_DASHBOARD -> {
                val user = currentUser
                if (user == null || !user.role.equals("ADMIN", ignoreCase = true)) {
                    // Unauthenticated or non-admin user is strictly redirected out of Admin Dashboard
                    LaunchedEffect(Unit) {
                        currentRoute = ScreenRoute.ADMIN_LOGIN
                    }
                } else {
                    AdminDashboardScreen(
                        repository = repository,
                        onNavigateBackToApp = {
                            currentRoute = ScreenRoute.MAIN_APP
                        },
                        onLogoutAdmin = {
                            repository.logout()
                            currentRoute = ScreenRoute.ADMIN_LOGIN
                        }
                    )
                }
            }

            ScreenRoute.CONTENT_REQUEST -> {
                ContentRequestScreen(
                    repository = repository,
                    onBackClick = {
                        currentRoute = ScreenRoute.MAIN_APP
                    }
                )
            }

            ScreenRoute.PREMIUM -> {
                PremiumSubscriptionScreen(
                    repository = repository,
                    onBackClick = {
                        currentRoute = ScreenRoute.MAIN_APP
                    }
                )
            }

            ScreenRoute.CONTENT_DETAIL -> {
                val cId = selectedContentId ?: "c_01"
                ContentDetailScreen(
                    contentId = cId,
                    repository = repository,
                    onBackClick = {
                        currentRoute = ScreenRoute.MAIN_APP
                    },
                    onWatchClick = { item, episode ->
                        selectedPlayerContent = item
                        selectedPlayerEpisode = episode
                        currentRoute = ScreenRoute.VIDEO_PLAYER
                    },
                    onRelatedContentClick = { relatedItem ->
                        selectedContentId = relatedItem.id
                    },
                    onCastClick = {
                        // Cast handling inside ContentDetailScreen
                    }
                )
            }

            ScreenRoute.VIDEO_PLAYER -> {
                selectedPlayerContent?.let { contentItem ->
                    VideoPlayerScreen(
                        content = contentItem,
                        episode = selectedPlayerEpisode,
                        repository = repository,
                        onBackClick = {
                            if (selectedContentId != null) {
                                currentRoute = ScreenRoute.CONTENT_DETAIL
                            } else {
                                currentRoute = ScreenRoute.MAIN_APP
                            }
                        },
                        onNavigateToPremium = {
                            currentRoute = ScreenRoute.PREMIUM
                        }
                    )
                } ?: run {
                    currentRoute = ScreenRoute.MAIN_APP
                }
            }

            ScreenRoute.MAIN_APP -> {
                MainAppScaffold(
                    repository = repository,
                    selectedTab = selectedBottomTab,
                    onTabSelected = { selectedBottomTab = it },
                    initialCategorySlug = initialCategorySlug,
                    onNavigateToDetail = { item ->
                        selectedContentId = item.id
                        currentRoute = ScreenRoute.CONTENT_DETAIL
                    },
                    onWatchDirect = { item ->
                        selectedPlayerContent = item
                        selectedPlayerEpisode = null
                        currentRoute = ScreenRoute.VIDEO_PLAYER
                    },
                    onNavigateToCategory = { slug ->
                        initialCategorySlug = slug
                        selectedBottomTab = BottomTab.CATEGORIES
                    },
                    onNavigateToRequest = {
                        currentRoute = ScreenRoute.CONTENT_REQUEST
                    },
                    onNavigateToPremium = {
                        currentRoute = ScreenRoute.PREMIUM
                    },
                    onNavigateToAdmin = {
                        if (currentUser?.role == "ADMIN") {
                            currentRoute = ScreenRoute.ADMIN_DASHBOARD
                        } else {
                            currentRoute = ScreenRoute.ADMIN_LOGIN
                        }
                    },
                    onNavigateToSearch = {
                        currentRoute = ScreenRoute.SEARCH
                    },
                    onLogout = {
                        repository.logout()
                        currentRoute = ScreenRoute.LOGIN
                    }
                )
            }
        }
    }
}

@Composable
fun MainAppScaffold(
    repository: StreamixRepository,
    selectedTab: BottomTab,
    onTabSelected: (BottomTab) -> Unit,
    initialCategorySlug: String,
    onNavigateToDetail: (ContentItem) -> Unit,
    onWatchDirect: (ContentItem) -> Unit,
    onNavigateToCategory: (String) -> Unit,
    onNavigateToRequest: () -> Unit,
    onNavigateToPremium: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onLogout: () -> Unit
) {
    val currentUser by repository.currentUser.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Main Top Header Bar (Brand Logo/Name + 🔍 Search Button)
            StreamixTopHeader(
                currentUser = currentUser,
                onSearchClick = onNavigateToSearch
            )

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(bottom = 60.dp)
            ) {
                when (selectedTab) {
                    BottomTab.HOME -> {
                        HomeScreen(
                            repository = repository,
                            onContentClick = onNavigateToDetail,
                            onWatchClick = onWatchDirect,
                            onNavigateToCategory = onNavigateToCategory,
                            onNavigateToRequest = onNavigateToRequest,
                            onNavigateToPremium = onNavigateToPremium
                        )
                    }
                    BottomTab.CATEGORIES -> {
                        CategoriesScreen(
                            repository = repository,
                            initialCategorySlug = initialCategorySlug,
                            onContentClick = onNavigateToDetail
                        )
                    }
                    BottomTab.MY_LIST -> {
                        MyListScreen(
                            repository = repository,
                            onContentClick = onNavigateToDetail,
                            onExploreClick = { onTabSelected(BottomTab.HOME) }
                        )
                    }
                    BottomTab.DOWNLOADS -> {
                        DownloadsScreen(
                            repository = repository,
                            onPlayDownload = { item ->
                                onWatchDirect(item)
                            },
                            onExploreContent = { onTabSelected(BottomTab.HOME) }
                        )
                    }
                    BottomTab.PROFILE -> {
                        ProfileScreen(
                            repository = repository,
                            onNavigateToAdmin = onNavigateToAdmin,
                            onNavigateToRequest = onNavigateToRequest,
                            onNavigateToPremium = onNavigateToPremium,
                            onLogout = onLogout
                        )
                    }
                }
            }
        }

        // Custom Glass Bottom Navigation Bar (5 tabs)
        CustomGlassBottomBar(
            selectedTab = selectedTab,
            onTabSelected = onTabSelected,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun CustomGlassBottomBar(
    selectedTab: BottomTab,
    onTabSelected: (BottomTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = 16.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = BrightRedAccent.copy(alpha = 0.45f),
                ambientColor = CrimsonRed.copy(alpha = 0.25f)
            )
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        DeepIndigoBg.copy(alpha = 0.94f),
                        DarkCharcoalBg.copy(alpha = 0.98f)
                    )
                )
            )
            .border(1.dp, GlassCardBorderRed.copy(alpha = 0.45f), RoundedCornerShape(24.dp))
            .padding(vertical = 6.dp, horizontal = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomTab.entries.forEach { tab ->
                val isSelected = selectedTab == tab

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .testTag(tab.testTag)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onTabSelected(tab) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .then(
                                if (isSelected) {
                                    Modifier
                                        .shadow(8.dp, CircleShape, spotColor = BrightRedAccent)
                                        .background(RedCrimsonGradient)
                                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                                } else Modifier.background(Color.Transparent)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = tab.title,
                            tint = if (isSelected) Color.White else TextSecondary,
                            modifier = Modifier.size(19.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = tab.title,
                        color = if (isSelected) BrightRedAccent else TextMuted,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightRedBackground),
        contentAlignment = Alignment.Center
    ) {
        // Ambient background glow
        Box(
            modifier = Modifier
                .size(260.dp)
                .background(
                    Brush.radialGradient(
                        listOf(
                            BrightRedAccent.copy(alpha = 0.30f),
                            CrimsonRed.copy(alpha = 0.15f),
                            Color.Transparent
                        )
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .shadow(
                        elevation = 22.dp,
                        shape = RoundedCornerShape(24.dp),
                        spotColor = BrightRedAccent.copy(alpha = 0.65f),
                        ambientColor = CrimsonRed.copy(alpha = 0.45f)
                    )
                    .clip(RoundedCornerShape(24.dp))
                    .background(RedButtonGradient)
                    .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Streamix BD",
                    tint = Color.White,
                    modifier = Modifier.size(50.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "STREAMIX BD",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Movies • Natok • Web Series • Films",
                color = BrightRedAccent,
                fontSize = 12.sp,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(36.dp))

            CircularProgressIndicator(
                color = BrightRedAccent,
                strokeWidth = 3.dp,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}
