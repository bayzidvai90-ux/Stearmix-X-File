package com.example.data.repository

import com.example.BuildConfig
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.ContentRequest
import com.example.data.model.Episode
import com.example.data.model.User
import java.security.MessageDigest

object SeedData {

    fun hashPassword(password: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(password.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Safely reads the configured admin password secret from the build environment.
     * Never exposes plaintext password in application logs or version control.
     */
    fun getAdminConfiguredPassword(): String? {
        return try {
            val envPass = BuildConfig.STREAMIX_ADMIN_PASSWORD
            if (!envPass.isNullOrBlank() && envPass != "STREAMIX_ADMIN_PASSWORD_DEFAULT") {
                envPass
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun getInitialAdminPasswordHash(): String {
        val configured = getAdminConfiguredPassword()
        return if (configured != null) {
            hashPassword(configured)
        } else {
            // High-entropy random baseline hash that prevents any default or trivial passwords from matching
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        }
    }

    val defaultAdmin: User
        get() = User(
            id = "admin_01",
            username = "admin",
            email = "admin@streamix.bd",
            passwordHash = getInitialAdminPasswordHash(),
            fullName = "Streamix Administrator",
            role = "ADMIN",
            status = "ACTIVE",
            avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80"
        )

    val defaultDemoUser = User(
        id = "user_01",
        username = "tanvir_bd",
        email = "tanvir@gmail.com",
        passwordHash = hashPassword("user123"),
        fullName = "Tanvir Ahmed",
        role = "USER",
        status = "ACTIVE",
        avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&auto=format&fit=crop&q=80",
        totalWatchTimeMinutes = 340,
        totalDownloads = 2
    )

    val categories = listOf(
        Category(id = "cat_all", name = "All Categories", slug = "all", iconName = "AutoAwesome", displayOrder = 0),
        Category(id = "cat_natok", name = "Bangla Natok", slug = "natok", iconName = "TheaterComedy", displayOrder = 1),
        Category(id = "cat_films", name = "Films & Cinema", slug = "films", iconName = "Movie", displayOrder = 2),
        Category(id = "cat_series", name = "Original Series", slug = "series", iconName = "Tv", displayOrder = 3),
        Category(id = "cat_thriller", name = "Crime & Thriller", slug = "thriller", iconName = "Psychology", displayOrder = 4),
        Category(id = "cat_romance", name = "Romantic Drama", slug = "romance", iconName = "Favorite", displayOrder = 5),
        Category(id = "cat_comedy", name = "Comedy Specials", slug = "comedy", iconName = "Mood", displayOrder = 6)
    )

    // Reliable public media video URLs (MP4 / HLS) for smooth playback and offline storage demonstration
    private const val STREAM_URL_1 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    private const val STREAM_URL_2 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    private const val STREAM_URL_3 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
    private const val STREAM_URL_4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
    private const val STREAM_URL_5 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
    private const val STREAM_URL_6 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"

    val initialContent = listOf(
        // Featured Hero Banner Item
        ContentItem(
            id = "c_01",
            title = "Pothohara - The Lost Path",
            type = "FILM",
            description = "A gritty psychological thriller set in old Dhaka streets. An investigative journalist uncovers a multi-layered conspiracy intertwining powerful syndicates with lost family heritage.",
            genre = "Crime / Thriller",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 142,
            rating = 4.9,
            posterUrl = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_5,
            trailerUrl = STREAM_URL_3,
            isFeatured = true,
            isTrending = true,
            isPopular = true,
            isPublished = true,
            viewsCount = 148500,
            categorySlug = "films",
            castAndCrew = "Afran Nisho, Mehazabien Chowdhury, Directed by Vicky Zahed",
            tags = "4K HDR, Dolby Atmos, 2024 Exclusive"
        ),
        ContentItem(
            id = "c_02",
            title = "Bhalobashar Nil Rong",
            type = "NATOK",
            description = "A heartwarming romantic drama capturing monsoon memories in Cox's Bazar and Dhaka. A gentle tale of second chances, acoustic music, and unwritten letters.",
            genre = "Romantic Drama",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 52,
            rating = 4.8,
            posterUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_1,
            isFeatured = true,
            isTrending = true,
            isPopular = true,
            isPublished = true,
            viewsCount = 92400,
            categorySlug = "natok",
            castAndCrew = "Ziaul Faruq Apurba, Tanjin Tisha, Directed by Mizanur Rahman Aryan",
            tags = "Romantic, Eid Special, 1080p Full HD"
        ),
        ContentItem(
            id = "c_03",
            title = "Chander Deshe",
            type = "SERIES",
            description = "A thrilling mystery series about five friends who journey to a remote hill tract in Bandarban, only to discover an ancient secret guarding an abandoned astronomical outpost.",
            genre = "Mystery / Adventure",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 240,
            rating = 4.7,
            posterUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_4,
            isFeatured = false,
            isTrending = true,
            isPopular = true,
            isPublished = true,
            viewsCount = 118200,
            categorySlug = "series",
            castAndCrew = "Chanchal Chowdhury, Mosharraf Karim, Directed by Nuhash Humayun",
            tags = "Season 1, 6 Episodes, 4K"
        ),
        ContentItem(
            id = "c_04",
            title = "Shohorer Golpo",
            type = "NATOK",
            description = "A witty and satirical comedy-drama detailing the hilarious day-to-day chaos of a shared flat in Dhanmondi, filled with budding musicians and eccentric tech startups.",
            genre = "Comedy / Slice of Life",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 48,
            rating = 4.6,
            posterUrl = "https://images.unsplash.com/photo-1514306191717-452ec28c7814?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_2,
            isFeatured = false,
            isTrending = false,
            isPopular = true,
            isPublished = true,
            viewsCount = 67300,
            categorySlug = "natok",
            castAndCrew = "Tawsif Mahbub, Sabila Nur, Directed by Kajal Arefin Ome",
            tags = "Comedy, Slice of Life, Full HD"
        ),
        ContentItem(
            id = "c_05",
            title = "Megh Roddur",
            type = "MOVIE",
            description = "An award-winning cinematic journey exploring the life of an acclaimed riverboat painter navigating changing delta landscapes and timeless folk music.",
            genre = "Drama / Music",
            language = "Bengali",
            releaseYear = 2023,
            durationMinutes = 135,
            rating = 4.9,
            posterUrl = "https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_6,
            isFeatured = false,
            isTrending = true,
            isPopular = true,
            isPublished = true,
            viewsCount = 204100,
            categorySlug = "films",
            castAndCrew = "Siam Ahmed, Porimoni, Directed by Raihan Rafi",
            tags = "Critically Acclaimed, 4K"
        ),
        ContentItem(
            id = "c_06",
            title = "Jokhon Nishi Raat",
            type = "SERIES",
            description = "A dark detective noir series following a haunted Dhaka CID officer solving a string of cryptic midnight art robberies in national heritage museums.",
            genre = "Crime / Noir",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 180,
            rating = 4.8,
            posterUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_3,
            isFeatured = false,
            isTrending = true,
            isPopular = true,
            isPublished = true,
            viewsCount = 89900,
            categorySlug = "series",
            castAndCrew = "Tariq Anam Khan, Shamol Mawla, Directed by Syed Ahmed Farez",
            tags = "Series, 4 Episodes, Thriller"
        ),
        ContentItem(
            id = "c_07",
            title = "Bikel Belar Gaan",
            type = "NATOK",
            description = "A nostalgic Eid telefilm focusing on two childhood sweethearts meeting again after a decade at the annual university campus reunion.",
            genre = "Romantic Drama",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 46,
            rating = 4.7,
            posterUrl = "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_1,
            isFeatured = false,
            isTrending = false,
            isPopular = false,
            isPublished = true,
            viewsCount = 45200,
            categorySlug = "natok",
            castAndCrew = "Farhan Ahmed Jovan, Keya Payel",
            tags = "Telefilm, HD"
        ),
        ContentItem(
            id = "c_08",
            title = "Agni Shorgo",
            type = "FILM",
            description = "High octane action blockbuster revolving around special anti-smuggling task force operatives in the Port of Chittagong.",
            genre = "Action / Thriller",
            language = "Bengali",
            releaseYear = 2024,
            durationMinutes = 150,
            rating = 4.5,
            posterUrl = "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=600&auto=format&fit=crop&q=80",
            backdropUrl = "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=1200&auto=format&fit=crop&q=80",
            videoUrl = STREAM_URL_5,
            isFeatured = false,
            isTrending = true,
            isPopular = true,
            isPublished = true,
            viewsCount = 132000,
            categorySlug = "films",
            castAndCrew = "Shakib Khan, Puja Cherry, Directed by Anonno Mamun",
            tags = "Blockbuster, 4K"
        )
    )

    val episodes = listOf(
        Episode(
            id = "ep_03_1",
            contentId = "c_03",
            seasonNumber = 1,
            episodeNumber = 1,
            title = "Episode 1: The Mountain Map",
            durationMinutes = 38,
            videoUrl = STREAM_URL_4,
            thumbnailUrl = "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=600&auto=format&fit=crop&q=80",
            description = "Five friends gather in Bandarban base camp to investigate an uncharted peak shown in an antique map."
        ),
        Episode(
            id = "ep_03_2",
            contentId = "c_03",
            seasonNumber = 1,
            episodeNumber = 2,
            title = "Episode 2: Echoes in the Mist",
            durationMinutes = 42,
            videoUrl = STREAM_URL_1,
            thumbnailUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80",
            description = "Strange signals disrupt communications as night falls over the valley."
        ),
        Episode(
            id = "ep_03_3",
            contentId = "c_03",
            seasonNumber = 1,
            episodeNumber = 3,
            title = "Episode 3: The Hidden Dome",
            durationMinutes = 44,
            videoUrl = STREAM_URL_2,
            thumbnailUrl = "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=600&auto=format&fit=crop&q=80",
            description = "They reach the observatory only to find it was not abandoned after all."
        ),
        Episode(
            id = "ep_06_1",
            contentId = "c_06",
            seasonNumber = 1,
            episodeNumber = 1,
            title = "Episode 1: The Midnight Heist",
            durationMinutes = 45,
            videoUrl = STREAM_URL_3,
            thumbnailUrl = "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=600&auto=format&fit=crop&q=80",
            description = "A legendary centuries-old emerald relic disappears during a storm outage."
        ),
        Episode(
            id = "ep_06_2",
            contentId = "c_06",
            seasonNumber = 1,
            episodeNumber = 2,
            title = "Episode 2: The Red Ledger",
            durationMinutes = 45,
            videoUrl = STREAM_URL_5,
            thumbnailUrl = "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=600&auto=format&fit=crop&q=80",
            description = "CID officer Kabir uncovers an underground black auction list in Old Dhaka."
        )
    )

    val sampleRequests = listOf(
        ContentRequest(
            id = "req_01",
            title = "Hawa (Director's Cut)",
            contentType = "MOVIE",
            requestedByUserId = "user_01",
            requestedByUsername = "tanvir_bd",
            description = "Please add the full uncut version with original score if authorized.",
            status = "APPROVED",
            submittedAt = System.currentTimeMillis() - 86400000L * 3,
            adminFeedback = "Approved. Digital streaming license is undergoing verification."
        ),
        ContentRequest(
            id = "req_02",
            title = "Buker Baap Pash",
            contentType = "NATOK",
            requestedByUserId = "user_01",
            requestedByUsername = "tanvir_bd",
            description = "Classic comedy natok starring Mosharraf Karim.",
            status = "COMPLETED",
            submittedAt = System.currentTimeMillis() - 86400000L * 7,
            adminFeedback = "Added to Bangla Natok catalog under classic comedy."
        ),
        ContentRequest(
            id = "req_03",
            title = "Mohanogor Season 3",
            contentType = "SERIES",
            requestedByUserId = "user_02",
            requestedByUsername = "rahim_99",
            description = "Looking forward to OC Harun next season!",
            status = "PENDING",
            submittedAt = System.currentTimeMillis() - 86400000L * 1,
            adminFeedback = ""
        )
    )

    val sampleAnnouncements = listOf(
        Announcement(
            id = "ann_01",
            title = "🎉 Welcome to Streamix BD Premium OTT",
            message = "Experience high-definition Bengali Natoks, original blockbuster movies, and series with ultra-low latency streaming and offline downloading.",
            imageUrl = "https://images.unsplash.com/photo-1578022761797-b8636ac1773c?w=800&auto=format&fit=crop&q=80",
            isActive = true,
            createdAt = System.currentTimeMillis() - 3600000L,
            authorName = "Streamix Team"
        ),
        Announcement(
            id = "ann_02",
            title = "🎬 New 4K HDR Releases Available This Week",
            message = "Enjoy newly remastered Dolby Audio and full 1080p/4K bitrate options for upcoming Eid special telefilms.",
            imageUrl = "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&auto=format&fit=crop&q=80",
            isActive = true,
            createdAt = System.currentTimeMillis() - 7200000L,
            authorName = "Content Desk"
        )
    )
}
