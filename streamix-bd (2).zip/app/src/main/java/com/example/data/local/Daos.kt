package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Announcement
import com.example.data.model.Category
import com.example.data.model.ContentItem
import com.example.data.model.ContentRequest
import com.example.data.model.DownloadItem
import com.example.data.model.Episode
import com.example.data.model.SavedItem
import com.example.data.model.User
import com.example.data.model.WatchHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): User?

    @Query("SELECT * FROM users WHERE LOWER(username) = LOWER(:usernameOrEmail) OR LOWER(email) = LOWER(:usernameOrEmail) LIMIT 1")
    suspend fun getUserByUsernameOrEmail(usernameOrEmail: String): User?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Query("UPDATE users SET status = :status WHERE id = :userId")
    suspend fun updateUserStatus(userId: String, status: String)

    @Query("UPDATE users SET isPremium = :isPremium, premiumPlan = :plan WHERE id = :userId")
    suspend fun updateUserPremiumStatus(userId: String, isPremium: Boolean, plan: String = "")

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getTotalUsersCount(): Int

    @Query("SELECT COUNT(*) FROM users WHERE status = 'ACTIVE'")
    suspend fun getActiveUsersCount(): Int

    @Query("SELECT COUNT(*) FROM users WHERE UPPER(role) = 'ADMIN'")
    suspend fun getAdminCount(): Int

    @Query("SELECT COUNT(*) FROM users WHERE UPPER(role) = 'ADMIN'")
    fun observeAdminCount(): Flow<Int>
}

@Dao
interface ContentDao {
    @Query("SELECT * FROM content_items WHERE isPublished = 1 ORDER BY releaseYear DESC, rating DESC")
    fun getAllPublishedContent(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items ORDER BY releaseYear DESC")
    fun getAllContentAdmin(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE id = :id LIMIT 1")
    suspend fun getContentById(id: String): ContentItem?

    @Query("SELECT * FROM content_items WHERE id = :id LIMIT 1")
    fun observeContentById(id: String): Flow<ContentItem?>

    @Query("SELECT * FROM content_items WHERE isFeatured = 1 AND isPublished = 1")
    fun getFeaturedContent(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE isTrending = 1 AND isPublished = 1")
    fun getTrendingContent(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE isPopular = 1 AND isPublished = 1")
    fun getPopularContent(): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE type = :type AND isPublished = 1")
    fun getContentByType(type: String): Flow<List<ContentItem>>

    @Query("SELECT * FROM content_items WHERE (title LIKE '%' || :query || '%' OR genre LIKE '%' || :query || '%' OR castAndCrew LIKE '%' || :query || '%') AND isPublished = 1")
    fun searchContent(query: String): Flow<List<ContentItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContent(item: ContentItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllContent(items: List<ContentItem>)

    @Update
    suspend fun updateContent(item: ContentItem)

    @Query("DELETE FROM content_items WHERE id = :id")
    suspend fun deleteContentById(id: String)

    @Query("UPDATE content_items SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("SELECT COUNT(*) FROM content_items")
    suspend fun getTotalContentCount(): Int

    @Query("SELECT COUNT(*) FROM content_items WHERE type = 'MOVIE'")
    suspend fun getMoviesCount(): Int

    @Query("SELECT COUNT(*) FROM content_items WHERE type = 'SERIES'")
    suspend fun getSeriesCount(): Int

    @Query("SELECT COUNT(*) FROM content_items WHERE type = 'NATOK'")
    suspend fun getNatokCount(): Int

    @Query("SELECT COUNT(*) FROM content_items WHERE type = 'FILM'")
    suspend fun getFilmsCount(): Int

    @Query("SELECT SUM(viewsCount) FROM content_items")
    suspend fun getTotalViews(): Long?
}

@Dao
interface EpisodeDao {
    @Query("SELECT * FROM episodes WHERE contentId = :contentId ORDER BY seasonNumber ASC, episodeNumber ASC")
    fun getEpisodesForContent(contentId: String): Flow<List<Episode>>

    @Query("SELECT * FROM episodes WHERE id = :episodeId LIMIT 1")
    suspend fun getEpisodeById(episodeId: String): Episode?

    @Query("SELECT COUNT(*) FROM episodes")
    suspend fun getTotalEpisodesCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEpisode(episode: Episode)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllEpisodes(episodes: List<Episode>)

    @Query("DELETE FROM episodes WHERE id = :episodeId")
    suspend fun deleteEpisodeById(episodeId: String)

    @Query("DELETE FROM episodes WHERE contentId = :contentId")
    suspend fun deleteEpisodesByContentId(contentId: String)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY displayOrder ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun getCategoryCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCategories(categories: List<Category>)

    @Update
    suspend fun updateCategory(category: Category)

    @Query("DELETE FROM categories WHERE id = :id")
    suspend fun deleteCategoryById(id: String)
}

@Dao
interface ContentRequestDao {
    @Query("SELECT * FROM content_requests ORDER BY submittedAt DESC")
    fun getAllRequests(): Flow<List<ContentRequest>>

    @Query("SELECT * FROM content_requests WHERE requestedByUserId = :userId ORDER BY submittedAt DESC")
    fun getRequestsByUser(userId: String): Flow<List<ContentRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequest(request: ContentRequest)

    @Query("UPDATE content_requests SET status = :status, adminFeedback = :feedback WHERE id = :requestId")
    suspend fun updateRequestStatus(requestId: String, status: String, feedback: String)

    @Query("DELETE FROM content_requests WHERE id = :requestId")
    suspend fun deleteRequest(requestId: String)

    @Query("SELECT COUNT(*) FROM content_requests WHERE status = 'PENDING'")
    suspend fun getPendingRequestsCount(): Int
}

@Dao
interface SavedItemDao {
    @Query("SELECT * FROM saved_items WHERE userId = :userId ORDER BY addedAt DESC")
    fun getSavedItemsForUser(userId: String): Flow<List<SavedItem>>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_items WHERE userId = :userId AND contentId = :contentId)")
    fun isSaved(userId: String, contentId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedItem(item: SavedItem)

    @Query("DELETE FROM saved_items WHERE userId = :userId AND contentId = :contentId")
    suspend fun removeSavedItem(userId: String, contentId: String)
}

@Dao
interface WatchHistoryDao {
    @Query("SELECT * FROM watch_history WHERE userId = :userId ORDER BY lastWatchedAt DESC")
    fun getWatchHistoryForUser(userId: String): Flow<List<WatchHistory>>

    @Query("SELECT * FROM watch_history WHERE userId = :userId AND contentId = :contentId AND episodeId = :episodeId LIMIT 1")
    suspend fun getWatchHistory(userId: String, contentId: String, episodeId: String): WatchHistory?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWatchHistory(history: WatchHistory)

    @Query("DELETE FROM watch_history WHERE userId = :userId AND contentId = :contentId")
    suspend fun deleteWatchHistory(userId: String, contentId: String)
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads WHERE userId = :userId ORDER BY downloadedAt DESC")
    fun getDownloadsForUser(userId: String): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE id = :downloadId LIMIT 1")
    suspend fun getDownloadById(downloadId: String): DownloadItem?

    @Query("SELECT * FROM downloads WHERE userId = :userId AND contentId = :contentId LIMIT 1")
    suspend fun getDownloadByContent(userId: String, contentId: String): DownloadItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(item: DownloadItem)

    @Update
    suspend fun updateDownload(item: DownloadItem)

    @Query("UPDATE downloads SET progress = :progress, status = :status WHERE id = :downloadId")
    suspend fun updateProgress(downloadId: String, progress: Float, status: String)

    @Query("DELETE FROM downloads WHERE id = :downloadId")
    suspend fun deleteDownload(downloadId: String)

    @Query("SELECT COUNT(*) FROM downloads WHERE status = 'COMPLETED'")
    suspend fun getTotalDownloadsCount(): Int
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements ORDER BY createdAt DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>

    @Query("SELECT * FROM announcements WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getActiveAnnouncements(): Flow<List<Announcement>>

    @Query("SELECT * FROM announcements WHERE id = :id LIMIT 1")
    suspend fun getAnnouncementById(id: String): Announcement?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAnnouncements(announcements: List<Announcement>)

    @Update
    suspend fun updateAnnouncement(announcement: Announcement)

    @Query("UPDATE announcements SET isActive = :isActive WHERE id = :id")
    suspend fun toggleAnnouncementActive(id: String, isActive: Boolean)

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncementById(id: String)

    @Query("SELECT COUNT(*) FROM announcements")
    suspend fun getTotalAnnouncementsCount(): Int

    @Query("SELECT COUNT(*) FROM announcements WHERE isActive = 1")
    suspend fun getActiveAnnouncementsCount(): Int
}
