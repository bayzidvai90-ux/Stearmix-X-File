package com.example.ui.screens.premium

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.StreamixRepository
import com.example.ui.components.GlassCard
import com.example.ui.components.StreamixFooter
import com.example.ui.theme.*

data class PremiumPlan(
    val id: String,
    val duration: String,
    val price: String,
    val priceNumeric: Int,
    val subtitle: String,
    val tag: String? = null,
    val isRecommended: Boolean = false,
    val savingsBadge: String? = null
)

val premiumPlansList = listOf(
    PremiumPlan(
        id = "plan_1_month",
        duration = "1 Month",
        price = "৳50",
        priceNumeric = 50,
        subtitle = "Standard monthly subscription",
        tag = "STANDARD",
        isRecommended = false,
        savingsBadge = "Basic Pass"
    ),
    PremiumPlan(
        id = "plan_3_months",
        duration = "3 Months",
        price = "৳229",
        priceNumeric = 229,
        subtitle = "Quarterly access pack",
        tag = "POPULAR",
        isRecommended = true,
        savingsBadge = "Most Popular"
    ),
    PremiumPlan(
        id = "plan_1_year",
        duration = "1 Year",
        price = "৳499",
        priceNumeric = 499,
        subtitle = "Full 12-month VIP pass",
        tag = "BEST VALUE",
        isRecommended = false,
        savingsBadge = "Save Big"
    )
)

data class PremiumBenefit(
    val icon: ImageVector,
    val title: String,
    val description: String
)

val premiumBenefitsList = listOf(
    PremiumBenefit(
        icon = Icons.Default.HighQuality,
        title = "Full HD & 4K Ultra Quality",
        description = "Highest bitrate streaming with zero buffer & crystal clear audio."
    ),
    PremiumBenefit(
        icon = Icons.Default.AutoAwesome,
        title = "100% Ad-Free Streaming",
        description = "Uninterrupted playback without banner, interstitial or video ads."
    ),
    PremiumBenefit(
        icon = Icons.Default.Download,
        title = "Unlimited Offline Downloads",
        description = "Save your favorite movies & drama series directly to your device."
    ),
    PremiumBenefit(
        icon = Icons.Default.Tv,
        title = "Smart TV & Multi-Device Access",
        description = "Cast smoothly to Android TV, Google TV, Chrome and tablets."
    ),
    PremiumBenefit(
        icon = Icons.Default.HeadsetMic,
        title = "Priority 24/7 VIP Support",
        description = "Direct WhatsApp priority assistance & instant drama request fulfillment."
    )
)

@Composable
fun PremiumSubscriptionScreen(
    repository: StreamixRepository,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var selectedPlanId by remember { mutableStateOf("plan_3_months") }
    val selectedPlan = premiumPlansList.firstOrNull { it.id == selectedPlanId } ?: premiumPlansList[1]

    val whatsappNumber = "+8801824553017"
    val whatsappUrl = "https://wa.me/8801824553017"

    fun openWhatsAppLink(planDuration: String, planPrice: String) {
        val message = "Hello Streamix BD Admin! I want to activate Streamix Premium ($planDuration - $planPrice). Please send me payment details."
        val encodedMessage = Uri.encode(message)
        val fullUrl = "$whatsappUrl?text=$encodedMessage"

        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val directIntent = Intent(Intent.ACTION_VIEW, Uri.parse(whatsappUrl)).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(directIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "WhatsApp link: $whatsappUrl", Toast.LENGTH_LONG).show()
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("premium_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Text(
                    text = "Streamix VIP Premium",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CrimsonRed.copy(alpha = 0.2f))
                        .border(1.dp, CrimsonRed.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = CrimsonRed,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PREMIUM",
                            color = TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Scrollable Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                // Hero VIP Banner Card
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = GlassCardBg,
                    borderColor = CrimsonRed.copy(alpha = 0.6f)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        DeepCrimson.copy(alpha = 0.35f),
                                        MidnightBlack.copy(alpha = 0.85f)
                                    )
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(CrimsonRed.copy(alpha = 0.2f))
                                    .border(2.dp, CrimsonRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = CrimsonRed,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "STREAMIX VIP PASS",
                                color = BrightRedAccent,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 2.sp
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "আনলিমিটেড এন্টারটেইনমেন্ট উপভোগ করুন",
                                color = TextPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "HD/4K স্ট্রিমিং, নো অ্যাডস এবং অফলাইন ডাউনলোডের প্রিমিয়াম সুবিধা পান সম্পূর্ণ নির্ভরযোগ্যভাবে।",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 17.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Section Title: Select Plan
                Text(
                    text = "SELECT YOUR SUBSCRIPTION PLAN",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Plan Cards
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    premiumPlansList.forEach { plan ->
                        val isSelected = plan.id == selectedPlanId
                        PlanSelectionCard(
                            plan = plan,
                            isSelected = isSelected,
                            onSelect = { selectedPlanId = plan.id }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Callout: WhatsApp Contact Payment
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = DarkCharcoalBg,
                    borderColor = BrightRedAccent.copy(alpha = 0.5f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = BrightRedAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ম্যানুয়াল WhatsApp পেমেন্ট প্রসেস",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "নির্বাচিত প্ল্যান: ${selectedPlan.duration} (${selectedPlan.price})\nWhatsApp-এ মেসেজ দিয়ে bKash / Nagad / Rocket পেমেন্ট সম্পন্ন করুন। অ্যাডমিন ম্যানুয়ালি আপনার অ্যাকাউন্ট ভেরিফাই করে সক্রিয় করবেন।",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Explicit Requested WhatsApp Button: “Premium নিতে WhatsApp-এ যোগাযোগ করুন”
                        Button(
                            onClick = {
                                openWhatsAppLink(selectedPlan.duration, selectedPlan.price)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("whatsapp_contact_payment_btn")
                                .shadow(
                                    elevation = 12.dp,
                                    shape = RoundedCornerShape(14.dp),
                                    spotColor = CrimsonRed.copy(alpha = 0.6f),
                                    ambientColor = DeepCrimson.copy(alpha = 0.4f)
                                ),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CrimsonRed,
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.HeadsetMic,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Premium নিতে WhatsApp-এ যোগাযোগ করুন",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Copy WhatsApp Number Row
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(GlassSurfaceDark)
                                .border(1.dp, GlassSoftBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    clipboardManager.setText(AnnotatedString(whatsappNumber))
                                    Toast.makeText(context, "WhatsApp নম্বর কপি করা হয়েছে ($whatsappNumber)", Toast.LENGTH_SHORT).show()
                                }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "WhatsApp No: $whatsappNumber",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy number",
                                tint = BrightRedAccent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Premium Benefits List
                Text(
                    text = "PREMIUM VIP ADVANTAGES",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    premiumBenefitsList.forEach { benefit ->
                        BenefitRowItem(benefit = benefit)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Activation Policy Notice
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = GlassSurfaceDark,
                    borderColor = GlassSoftBorder
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = EmeraldGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "অ্যাক্টিভেশন পলিসি ও নিরাপত্তা",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• পেমেন্ট স্ক্রিনশট বা ট্রানজেকশন আইডি WhatsApp-এ পাঠালে অ্যাডমিন ১০–৩০ মিনিটের মধ্যে যাচাই করে প্রিমিয়াম অ্যাক্টিভ করে দেবে।\n• কোনও ব্যাংক পাসওয়ার্ড বা গোপন পিন কারও সাথে শেয়ার করবেন না।\n• অ্যাপের মধ্যে কোনও গোপন পাসওয়ার্ড বা সেনসিটিভ ডেটা সেভ করা হয় না।",
                            color = TextMuted,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                StreamixFooter()

                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun PlanSelectionCard(
    plan: PremiumPlan,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val borderColor = if (isSelected) CrimsonRed else GlassCardBorder
    val backgroundColor = if (isSelected) GlassCardHover else GlassSurfaceDark

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onSelect
            )
            .padding(16.dp)
            .testTag("plan_card_${plan.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Radio-like Selection Circle
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .border(
                        2.dp,
                        if (isSelected) CrimsonRed else TextMuted,
                        CircleShape
                    )
                    .background(if (isSelected) CrimsonRed else Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Plan Info
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = plan.duration,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    plan.savingsBadge?.let { badge ->
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (plan.isRecommended) CrimsonRed else DarkRuby)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badge,
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = plan.subtitle,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            // Price Display
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = plan.price,
                    color = if (isSelected) BrightRedAccent else TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "BDT",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun BenefitRowItem(benefit: PremiumBenefit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(GlassSurfaceDark)
            .border(1.dp, GlassSoftBorder, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CrimsonRed.copy(alpha = 0.15f))
                .border(1.dp, CrimsonRed.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = benefit.icon,
                contentDescription = null,
                tint = BrightRedAccent,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = benefit.title,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = benefit.description,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}
