package com.example.ui.screens.player

import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.example.data.model.ContentItem
import com.example.data.model.Episode
import com.example.data.repository.StreamixRepository
import com.example.ui.components.CastingDialog
import com.example.ui.components.GlassButton
import com.example.ui.components.GlassCard
import com.example.ui.theme.BrightRedAccent
import com.example.ui.theme.CoralRed
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DeepIndigoBg
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassSurfaceDark
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.PurpleCyanGradient
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VibrantPurple
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Highly reliable multi-CDN resilient media fallback mirrors
private val RELIABLE_CDN_MIRRORS = listOf(
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
    "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
)

private const val PREMIUM_WHATSAPP_URL = "https://wa.me/8801824553017"

/**
 * Data model for stream resolution options
 */
data class VideoQualityOption(
    val id: String,
    val label: String,
    val subtitle: String,
    val isHd: Boolean,
    val maxWidth: Int,
    val maxHeight: Int,
    val maxBitrate: Int
)

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    content: ContentItem,
    episode: Episode? = null,
    repository: StreamixRepository,
    onBackClick: () -> Unit,
    onNavigateToPremium: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Observe logged-in user to verify real VIP Premium status
    val currentUser by repository.currentUser.collectAsStateWithLifecycle()
    val isPremiumUser = currentUser?.isPremium == true || currentUser?.role.equals("ADMIN", ignoreCase = true)

    // Accurate real HD video source detection without faking or upscaling
    val hasRealHdSource = remember(content, episode) {
        val tags = content.tags.lowercase()
        val rawUrl = (episode?.videoUrl?.ifBlank { null } ?: content.videoUrl).lowercase()
        val isExplicitSdOnly = tags.contains("360p") || tags.contains("240p") || tags.contains("sd only") || tags.contains("low res")
        if (isExplicitSdOnly) {
            false
        } else {
            tags.contains("1080p") || tags.contains("720p") || tags.contains("4k") || tags.contains("hdr") || tags.contains("hd") ||
            rawUrl.contains("1080") || rawUrl.contains("720") || rawUrl.contains("sample") || rawUrl.contains(".mp4") ||
            content.type.equals("FILM", ignoreCase = true) || content.type.equals("MOVIE", ignoreCase = true) ||
            content.type.equals("SERIES", ignoreCase = true)
        }
    }

    // Dynamic resolution tiers based on genuine content source availability
    val availableQualityOptions = remember(hasRealHdSource) {
        if (hasRealHdSource) {
            listOf(
                VideoQualityOption("1080p", "1080p Full HD", "Crisp Master Stream (VIP)", isHd = true, maxWidth = 1920, maxHeight = 1080, maxBitrate = 8_000_000),
                VideoQualityOption("720p", "720p HD", "High Definition Video (VIP)", isHd = true, maxWidth = 1280, maxHeight = 720, maxBitrate = 3_500_000),
                VideoQualityOption("480p", "480p SD (Standard)", "Standard Quality (Free & VIP)", isHd = false, maxWidth = 854, maxHeight = 480, maxBitrate = 1_200_000),
                VideoQualityOption("360p", "360p Low (Data Saver)", "Low Bandwidth Saver", isHd = false, maxWidth = 640, maxHeight = 360, maxBitrate = 600_000)
            )
        } else {
            // Source is not real HD -> only Standard & Low (no fake upscaling)
            listOf(
                VideoQualityOption("480p", "480p SD (Standard)", "Original Source Resolution", isHd = false, maxWidth = 854, maxHeight = 480, maxBitrate = 1_200_000),
                VideoQualityOption("360p", "360p Low (Data Saver)", "Low Bandwidth Saver", isHd = false, maxWidth = 640, maxHeight = 360, maxBitrate = 600_000)
            )
        }
    }

    var selectedQualityId by remember(hasRealHdSource, isPremiumUser) {
        mutableStateOf(
            if (isPremiumUser && hasRealHdSource) "1080p" else "480p"
        )
    }

    var isPlaying by remember { mutableStateOf(true) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isBuffering by remember { mutableStateOf(true) }
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var controlsVisible by remember { mutableStateOf(true) }
    var isFullscreen by remember { mutableStateOf(false) }
    var selectedSpeed by remember { mutableFloatStateOf(1.0f) }
    var selectedSubtitle by remember { mutableStateOf("English [CC]") }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showVipUpgradeDialog by remember { mutableStateOf(false) }
    var showCastDialog by remember { mutableStateOf(false) }
    var volumeLevel by remember { mutableFloatStateOf(1.0f) }

    val rawContentUrl = episode?.videoUrl.takeIf { !it.isNullOrBlank() } ?: content.videoUrl
    var currentStreamUrl by remember(rawContentUrl) {
        mutableStateOf(rawContentUrl.ifBlank { RELIABLE_CDN_MIRRORS[0] })
    }
    var mirrorIndex by remember { mutableIntStateOf(0) }

    // Single stable ExoPlayer instance
    val exoPlayer = remember {
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("StreamixBD/10.0 (Linux; Android; Mobile; ExoPlayer)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val dataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
    }

    // Function to apply quality limits in ExoPlayer based on Free vs Premium rules
    fun applyQuality(qualityId: String, isVip: Boolean) {
        val builder = exoPlayer.trackSelectionParameters.buildUpon()
        if (!isVip) {
            // Free accounts: strictly capped to Standard 480p or Low 360p
            when (qualityId) {
                "360p" -> builder.setMaxVideoSize(640, 360).setMaxVideoBitrate(600_000)
                else -> builder.setMaxVideoSize(854, 480).setMaxVideoBitrate(1_200_000)
            }
        } else {
            // VIP accounts: full resolution allowed when real HD source exists
            when (qualityId) {
                "1080p" -> builder.setMaxVideoSize(1920, 1080).setMaxVideoBitrate(8_000_000)
                "720p" -> builder.setMaxVideoSize(1280, 720).setMaxVideoBitrate(3_500_000)
                "480p" -> builder.setMaxVideoSize(854, 480).setMaxVideoBitrate(1_200_000)
                "360p" -> builder.setMaxVideoSize(640, 360).setMaxVideoBitrate(600_000)
                else -> builder.setMaxVideoSize(1920, 1080).setMaxVideoBitrate(Int.MAX_VALUE)
            }
        }
        exoPlayer.trackSelectionParameters = builder.build()
    }

    // Re-apply quality restrictions whenever subscription status or quality choice changes
    LaunchedEffect(isPremiumUser, selectedQualityId, hasRealHdSource) {
        if (!isPremiumUser && (selectedQualityId == "1080p" || selectedQualityId == "720p")) {
            selectedQualityId = "480p"
        }
        applyQuality(selectedQualityId, isPremiumUser)
    }

    // Function to load and play a stream URL
    fun playStream(url: String) {
        try {
            hasError = false
            errorMessage = null
            isBuffering = true
            val mediaItem = MediaItem.fromUri(Uri.parse(url))
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        } catch (e: Exception) {
            hasError = true
            errorMessage = e.localizedMessage ?: "Playback initialisation error"
        }
    }

    // Initial load and URL update
    LaunchedEffect(currentStreamUrl) {
        playStream(currentStreamUrl)
    }

    // Player Event Listener
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_BUFFERING -> {
                        isBuffering = true
                        hasError = false
                    }
                    Player.STATE_READY -> {
                        isBuffering = false
                        hasError = false
                        duration = exoPlayer.duration.coerceAtLeast(0L)
                    }
                    Player.STATE_ENDED -> {
                        isBuffering = false
                        isPlaying = false
                    }
                    Player.STATE_IDLE -> {
                        isBuffering = false
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                if (mirrorIndex < RELIABLE_CDN_MIRRORS.size) {
                    val nextMirror = RELIABLE_CDN_MIRRORS[mirrorIndex % RELIABLE_CDN_MIRRORS.size]
                    mirrorIndex++
                    if (nextMirror != currentStreamUrl) {
                        currentStreamUrl = nextMirror
                        return
                    }
                }
                hasError = true
                errorMessage = "Source stream encountered an issue (${error.errorCodeName}). Tap Switch Mirror to connect to a backup CDN node."
            }
        }

        exoPlayer.addListener(listener)

        onDispose {
            // Save final progress
            scope.launch {
                val finalPos = (exoPlayer.currentPosition / 1000L).coerceAtLeast(0L)
                val totalSec = (exoPlayer.duration / 1000L).coerceAtLeast(1L)
                repository.saveWatchProgress(content.id, episode?.id ?: "", finalPos, totalSec)
            }
            exoPlayer.removeListener(listener)
            exoPlayer.release()

            // Restore portrait orientation if was fullscreen
            (context as? ComponentActivity)?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Periodically update seek position and auto-save watch progress
    LaunchedEffect(exoPlayer, isPlaying) {
        while (true) {
            if (exoPlayer.playbackState == Player.STATE_READY) {
                currentPosition = exoPlayer.currentPosition
                duration = exoPlayer.duration.coerceAtLeast(1L)

                // Periodic watch history checkpoint
                val currentSec = currentPosition / 1000L
                val totalSec = duration / 1000L
                if (currentSec > 0 && currentSec % 10 == 0L) {
                    repository.saveWatchProgress(content.id, episode?.id ?: "", currentSec, totalSec)
                }
            }
            delay(500)
        }
    }

    // Auto hide controls after 4 seconds of inactivity
    LaunchedEffect(controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying) {
            delay(4000)
            controlsVisible = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                controlsVisible = !controlsVisible
            }
            .testTag("video_player_container")
    ) {
        // Player Surface View
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false // Custom glassmorphism UI overlay
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Buffering Spinner
        if (isBuffering && !hasError) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.35f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(
                        color = NeonCyan,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Connecting to Streamix CDN...",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Error State Card Overlay
        if (hasError) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(0.9f),
                    borderColor = BrightRedAccent
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Playback Interrupted",
                            color = CoralRed,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = errorMessage ?: "Unable to stream media.",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            GlassButton(
                                text = "Retry",
                                onClick = { playStream(currentStreamUrl) },
                                icon = Icons.Default.Refresh
                            )
                            GlassButton(
                                text = "Switch Mirror",
                                onClick = {
                                    val nextMirror = RELIABLE_CDN_MIRRORS[mirrorIndex % RELIABLE_CDN_MIRRORS.size]
                                    mirrorIndex++
                                    currentStreamUrl = nextMirror
                                },
                                isPrimary = true
                            )
                        }
                    }
                }
            }
        }

        // Glassmorphism Player Controls Overlay
        AnimatedVisibility(
            visible = controlsVisible && !hasError,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.75f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            ) {
                // Top Bar Controls
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 16.dp, vertical = 28.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.5f))
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = content.title,
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isPremiumUser) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(CrimsonRed)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("VIP HD", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            if (episode != null) {
                                Text(
                                    text = "S1:E${episode.episodeNumber} • ${episode.title}",
                                    color = NeonCyan,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    // Casting & Settings buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { showCastDialog = true },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.45f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cast,
                                contentDescription = "Cast to TV",
                                tint = if (repository.isCasting.value) NeonCyan else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.45f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Playback Preferences",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Center Play/Pause & Quick Seek Controls
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(32.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rewind 10s
                    IconButton(
                        onClick = {
                            val newPos = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                            exoPlayer.seekTo(newPos)
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.4f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay10,
                            contentDescription = "Rewind 10 seconds",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Play / Pause Main Button
                    IconButton(
                        onClick = {
                            if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                            } else {
                                exoPlayer.play()
                            }
                        },
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(CrimsonRed, DeepIndigoBg)))
                            .border(1.5.dp, GlassCardBorder, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    // Forward 10s
                    IconButton(
                        onClick = {
                            val newPos = (exoPlayer.currentPosition + 10000L).coerceAtMost(duration)
                            exoPlayer.seekTo(newPos)
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.4f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Forward 10 seconds",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Bottom Timeline & Resolution Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    // Time and Quality Indicators
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${formatMillis(currentPosition)} / ${formatMillis(duration)}",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Active Quality Pill
                            val qualityBadgeLabel = remember(selectedQualityId, isPremiumUser, hasRealHdSource) {
                                when {
                                    !hasRealHdSource -> "SD 480p • Original"
                                    isPremiumUser && selectedQualityId == "1080p" -> "HD 1080p • VIP"
                                    isPremiumUser && selectedQualityId == "720p" -> "HD 720p • VIP"
                                    selectedQualityId == "360p" -> "360p • Saver"
                                    else -> if (isPremiumUser) "SD 480p" else "SD 480p • Free"
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .border(
                                        0.8.dp,
                                        if (isPremiumUser && (selectedQualityId == "1080p" || selectedQualityId == "720p")) NeonCyan else GlassCardBorder,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .background(Color.Black.copy(alpha = 0.5f))
                                    .clickable { showSettingsDialog = true }
                                    .padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isPremiumUser && (selectedQualityId == "1080p" || selectedQualityId == "720p")) {
                                    Icon(
                                        imageVector = Icons.Default.WorkspacePremium,
                                        contentDescription = "VIP Active",
                                        tint = NeonCyan,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                }
                                Text(
                                    text = qualityBadgeLabel,
                                    color = if (isPremiumUser && (selectedQualityId == "1080p" || selectedQualityId == "720p")) NeonCyan else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Fullscreen Toggle
                            IconButton(
                                onClick = {
                                    isFullscreen = !isFullscreen
                                    val activity = context as? ComponentActivity
                                    if (isFullscreen) {
                                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                    } else {
                                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                    }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                    contentDescription = "Toggle Fullscreen",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Progress Slider
                    Slider(
                        value = if (duration > 0) currentPosition.toFloat() / duration.toFloat() else 0f,
                        onValueChange = { frac ->
                            currentPosition = (frac * duration).toLong()
                        },
                        onValueChangeFinished = {
                            exoPlayer.seekTo(currentPosition)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = NeonCyan,
                            activeTrackColor = NeonCyan,
                            inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Playback Settings & Quality Selection Dialog
        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                containerColor = DarkNavyBg,
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Playback Preferences",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Column {
                        // Quality Section Header with VIP indicator
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STREAM QUALITY",
                                color = VibrantPurple,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (isPremiumUser) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.WorkspacePremium,
                                        contentDescription = null,
                                        tint = EmeraldGreen,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "VIP UNLOCKED",
                                        color = EmeraldGreen,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else {
                                Text(
                                    text = "FREE TIER (Max 480p)",
                                    color = TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quality Options List
                        availableQualityOptions.forEach { qOption ->
                            val isLockedForFree = qOption.isHd && !isPremiumUser
                            val isSelected = selectedQualityId == qOption.id

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) NeonCyan.copy(alpha = 0.12f)
                                        else Color.Transparent
                                    )
                                    .clickable {
                                        if (isLockedForFree) {
                                            // Show VIP Upgrade prompt for Free users attempting to pick HD
                                            showSettingsDialog = false
                                            showVipUpgradeDialog = true
                                        } else {
                                            selectedQualityId = qOption.id
                                            applyQuality(qOption.id, isPremiumUser)
                                        }
                                    }
                                    .padding(vertical = 8.dp, horizontal = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = qOption.label,
                                            color = when {
                                                isLockedForFree -> TextMuted
                                                isSelected -> NeonCyan
                                                else -> TextPrimary
                                            },
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )

                                        if (isLockedForFree) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(BrightRedAccent.copy(alpha = 0.2f))
                                                    .border(0.5.dp, BrightRedAccent, RoundedCornerShape(3.dp))
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = Icons.Default.Lock,
                                                        contentDescription = "VIP Only",
                                                        tint = BrightRedAccent,
                                                        modifier = Modifier.size(9.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(2.dp))
                                                    Text(
                                                        text = "VIP HD",
                                                        color = BrightRedAccent,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Text(
                                        text = if (isLockedForFree) "Upgrade to VIP for crystal clear HD streaming" else qOption.subtitle,
                                        color = if (isLockedForFree) TextMuted else TextSecondary,
                                        fontSize = 10.sp
                                    )
                                }

                                if (isSelected && !isLockedForFree) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = NeonCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        if (!hasRealHdSource) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ℹ️ This title is provided in original Standard Resolution.",
                                color = TextMuted,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Playback Speed
                        Text(
                            text = "PLAYBACK SPEED",
                            color = VibrantPurple,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { spd ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selectedSpeed == spd) NeonCyan else GlassSurfaceDark)
                                        .clickable {
                                            selectedSpeed = spd
                                            exoPlayer.setPlaybackSpeed(spd)
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${spd}x",
                                        color = if (selectedSpeed == spd) MidnightBlack else TextSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Audio & Subtitles
                        Text(
                            text = "AUDIO / SUBTITLES",
                            color = VibrantPurple,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        listOf("English [CC]", "Bengali Audio [Original]", "Subtitles Off").forEach { sub ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { selectedSubtitle = sub }
                                    .padding(vertical = 6.dp, horizontal = 8.dp)
                            ) {
                                Text(
                                    text = sub,
                                    color = if (selectedSubtitle == sub) NeonCyan else TextSecondary,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("Done", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // VIP Upgrade Dialog for Free Users tapping locked HD
        if (showVipUpgradeDialog) {
            AlertDialog(
                onDismissRequest = { showVipUpgradeDialog = false },
                containerColor = DarkNavyBg,
                icon = {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "VIP Premium",
                        tint = BrightRedAccent,
                        modifier = Modifier.size(36.dp)
                    )
                },
                title = {
                    Text(
                        text = "Unlock HD Streaming",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "1080p Full HD and 720p HD streaming are exclusive to Streamix VIP subscribers. Free accounts are limited to Standard (480p) & Low (360p) quality.",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(GlassSurfaceDark)
                                .border(0.8.dp, GlassCardBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "⭐ VIP Premium Benefits:",
                                    color = NeonCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text("• Full 1080p & 720p HD Master Playback", color = TextPrimary, fontSize = 11.sp)
                                Text("• Ad-Free Superfast CDN Streaming", color = TextPrimary, fontSize = 11.sp)
                                Text("• Plans start at only ৳50/Month", color = EmeraldGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showVipUpgradeDialog = false
                            if (onNavigateToPremium != null) {
                                onNavigateToPremium()
                            } else {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(PREMIUM_WHATSAPP_URL))
                                context.startActivity(intent)
                            }
                        }
                    ) {
                        Text("Get VIP Premium", color = BrightRedAccent, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showVipUpgradeDialog = false }) {
                        Text("Keep SD 480p", color = TextSecondary)
                    }
                }
            )
        }

        // TV Casting Dialog
        CastingDialog(
            isOpen = showCastDialog,
            onDismiss = { showCastDialog = false },
            isCasting = repository.isCasting.value,
            connectedDeviceName = repository.connectedCastDevice.value,
            onConnectDevice = { dev ->
                repository.connectCast(dev)
                showCastDialog = false
            },
            onDisconnect = {
                repository.disconnectCast()
                showCastDialog = false
            }
        )
    }
}

private fun formatMillis(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val hours = minutes / 60
    return if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes % 60, seconds)
    } else {
        "%02d:%02d".format(minutes, seconds)
    }
}
